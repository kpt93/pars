#!/bin/sh
echo "Installing PW Libs"
sudo cp *.so  /usr/lib/arm-linux-gnueabihf/.
exit
