# pwomxplayer-support
few support files
copy them into /usr/lib/arm-linux-gnueabihf/. and run pwomxplayer normally on Rpi latest OS 11 (bullseye)
